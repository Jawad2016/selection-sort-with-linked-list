/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.selectionsortlinkedlist;

/**
 *
 * @author Jawad Royesh
 */
public class SelectionSortLinkedList {
         Node head;

    public SelectionSortLinkedList() {
        this.head = null;
    }
     public void addlast(int data){
     Node newnode = new Node(data);
     if(head == null){
         head = newnode;
         newnode.next = head;
     }
     else {
         Node temp = head;
         while(temp.next !=null){
             temp = temp.next;
         }
         temp.next = newnode;
     }
     } 
     public void show(){
     
         Node temp = head;
         while(temp !=null){
         System.out.print(temp.data + " ");
         temp = temp.next;
         }
     }
     
     public void selecTionSort(){
     
         for(Node i = head; i !=null; i=i.next){
             Node min = i;
             for(Node j = i.next; j !=null ; j=j.next){
                 if(j.data < i.data)
                 min = j;
             }
             // swapp 
             int temp = i.data;
             i.data = min.data;
             min.data = temp;
         }
     }
    public static void main(String[] args) {
        SelectionSortLinkedList ssl = new SelectionSortLinkedList();
        ssl.addlast(56);
        ssl.addlast(45);
        ssl.addlast(23);
        ssl.addlast(89);
        ssl.addlast(10);
        System.out.println("Befor selection sort");
        ssl.show();
        ssl.selecTionSort();
        System.out.println("\nAfter selection sort");
        ssl.show();
    }
}
